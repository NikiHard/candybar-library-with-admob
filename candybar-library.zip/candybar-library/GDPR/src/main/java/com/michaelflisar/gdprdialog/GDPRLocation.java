package com.michaelflisar.gdprdialog;

public enum GDPRLocation {
    UNDEFINED,
    IN_EAA_OR_UNKNOWN,
    NOT_IN_EAA
}
